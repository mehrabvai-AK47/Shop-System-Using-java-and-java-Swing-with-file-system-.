import Classes.Home;

public class Start {
   public Start() {
   }

   public static void main(String[] var0) {
      new Home();
   }
}